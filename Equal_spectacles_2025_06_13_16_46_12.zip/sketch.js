let player;
let items = [];
let totalItems = 50;
let timeLeft = 60;
let gameOver = false;
let win = false;

function setup() {
  createCanvas(600, 400);
  player = createVector(width / 2, height / 2);
  textAlign(CENTER, CENTER);
  textSize(20);

  for (let i = 0; i < totalItems; i++) {
    items.push(createVector(random(width), random(height)));
  }

  setInterval(() => {
    if (!gameOver && !win) {
      timeLeft--;
      if (timeLeft <= 0) {
        gameOver = true;
      }
    }
  }, 1000);
}

function draw() {
  background(30);
  
  // Player
  fill(0, 200, 255);
  ellipse(player.x, player.y, 30, 30);
  
  // Milhos
  textSize(24);
  for (let i = items.length - 1; i >= 0; i--) {
    let item = items[i];
    text('🌽', item.x, item.y);
    
    if (dist(player.x, player.y, item.x, item.y) < 25) {
      items.splice(i, 1);
    }
  }

  // Win check
  if (items.length === 0 && !gameOver) {
    win = true;
  }

  // Movement
  if (!gameOver && !win) {
    if (keyIsDown(LEFT_ARROW)) player.x -= 4;
    if (keyIsDown(RIGHT_ARROW)) player.x += 4;
    if (keyIsDown(UP_ARROW)) player.y -= 4;
    if (keyIsDown(DOWN_ARROW)) player.y += 4;
  }

  // UI
  fill(255);
  textSize(18);
  textAlign(LEFT, TOP);
  text("Tempo: " + timeLeft, 10, 10);
  text("Milhos restantes: " + items.length, 10, 30);

  if (gameOver) {
    textSize(32);
    textAlign(CENTER, CENTER);
    text("Tempo Esgotado!", width / 2, height / 2);
  } else if (win) {
    textSize(32);
    textAlign(CENTER, CENTER);
    text("Você Venceu!", width / 2, height / 2);
  }
}